<p style="font-size:30px; font-wight:bloder; text-align:center ">Tianracer F1TENTH 仿真实例 </p>

### 1.简介

Tianracer_gazebo 是一个基于Gazebo的Tianracer的仿真环境，在这个仿真环境中，仍然可以通过阅读Tianracer使用手册，来进行仿真调试。  

### 2.如何运行 

使用下面的命令即可运行仿真环境

```shell
roslaunch tianracer_gazebo demo_tianracer_teb_nav.launch
```

### 3.如何魔改

....TODO....
