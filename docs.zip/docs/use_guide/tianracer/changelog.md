<p style="font-size:30px ; font-weight:bolder; text-align:center"> 更新日志</p>

Oct 28, 2021

    tianracer_competiton updated

Oct 11, 2021

    urdf rplidar pose fix. amcl param adjust, relocation disabled.

Sep 18, 2021

    t108 reconfigured

Sep 13, 2021

    add T108 new type support
    add tianracer compact urdf

Aug 18, 2021

    Merge pull request #2 from WGQ-CN/master
    Updated readme.txt and changed Python version to python2

Aug 14, 2021

    The "distinction extender" algorithm of UNC-Chapel Hill is reproduced

Jul 30, 2021

    update readme

Jan 29, 2021

add points to obstacle layer
Jan 28, 2021

    improve tianracer pro drivers

Nov 5, 2020

    update Readme. add CN version

Oct 31, 2020

    pro navigation tuned

Oct 29, 2020

    update teb
    add map_save
    add realsense view
    tianracer fullsize init
    add ipynb
    pro branch init

Oct 27, 2020

    improve teb param

Oct 26, 2020

    param improved

Oct 17, 2020

    report error when commucation timeout
    add a lock for serial mutual exclusion

Sep 3, 2020

    add jetracer ipynb
    change env prefix to TIANRACER

Aug 31, 2020

    add wall following simulation

Aug 7, 2020

    bridge enabled

Jul 30, 2020

    add hector_slam

Jul 28, 2020

    add usb_cam

Jul 25, 2020

    rm laser only cartographer

Jul 21, 2020

    teb launch bug fix
    view teb planner
    teb local planner
    L1 controller navigation for ackermann_cmd

Jul 13, 2020

    L1_controller bug fix

Jul 11, 2020

    L1 controller change to ackermann_cmd

Jul 9, 2020

    rs_camera update

Jun 16, 2020

    update tianracer_rviz

Jun 15, 2020

    rm core tf pub
    change default joy mode to x
    change joy default to X
    rm keyop. add joy_dev. add cmd to ackermann script.

Jun 10, 2020

    teleop ackermann
