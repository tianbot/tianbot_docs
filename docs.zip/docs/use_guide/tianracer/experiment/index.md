# tianracer实验

- [实验一、实验工具的使用](/use_guide/tianracer/experiment/chapter1.md)
- [实验二 ROS控制底盘运动](/use_guide/tianracer/experiment/chapter2.md)
- [实验三 反应式方法](/use_guide/tianracer/experiment/chapter3.md)
- [实验四 定位与建图SLAM](/use_guide/tianracer/experiment/chapter4.md)
- [实验五 Cartographer与TEB详解](/use_guide/tianracer/experiment/chapter5.md)
- [实验六 自主导航](/use_guide/tianracer/experiment/chapter6.md)
- [实验七 多点导航](/use_guide/tianracer/experiment/chapter7.md)
- [实验八 深度学习与视觉导航](/use_guide/tianracer/experiment/chapter8.md)
- [线上挑战赛](/use_guide/tianracer/experiment/racer_offline.md)
- [线下挑战赛](/use_guide/tianracer/experiment/racer_online.md)

.........TODO.............
