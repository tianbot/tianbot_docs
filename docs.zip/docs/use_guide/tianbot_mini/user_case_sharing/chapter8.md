<p style="font-size:30px; font-weight: bolder; text-align:center ">Tianbot mini开箱~</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/21
>
> 原文作者：LinLIinLin
>
> 原文标题：Tianbot mini开箱~


顺丰今天上午到，我在中午终于通过人山人海的快递拿到了我的mini。

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646407.webp)

（很安全的顺丰包装）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646264.webp)

我还以为这个会很大，其实实际尺寸并没有那么大，只有20cm14cm13cm，重量也没有很重（我还找了好久有没有钥匙呢，发现其实并没有，那这个锁洞是干啥的哈哈哈哈）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646410.webp)

第一层打开就是这样啦，这里再提醒一下大家！这是分层的！！我一开始还不知道，就一直很暴力的想提着小车尾翼拿出来。还扣了半天那个洞，想看看里面是啥子。

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646097.webp)

（暴力的后果，隔板都有点变形了）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646383.webp)

拿开隔板以后第二层就是这样啦，有三根天线和一根usb数据线

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281646383.webp)

还有送贴纸哦！！我最喜欢这种有纪念意义的小东西了，但是非常可惜的是由于那个保护箱表面的颗粒凸起，这个贴纸在上面根本贴不牢。
