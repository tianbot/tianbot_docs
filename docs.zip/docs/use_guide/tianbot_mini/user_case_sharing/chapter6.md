<p style="font-size:30px; font-weight: bolder; text-align:center ">tianbot mini开箱贴-fuct1_7292</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/19
>
> 原文作者：fuct1_7292
>
> 原文标题：tianbot mini开箱贴-fuct1_7292


![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281619102.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281619971.webp)

