<p style="font-size:30px; font-weight: bolder; text-align:center ">整活了tianbot mini 版turtlebot</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/177
>
> 原文作者：独角兽先生
>
> 原文标题：整活了tianbot mini 版turtlebot

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281707289.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281707345.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281707514.webp)

