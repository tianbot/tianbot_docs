<p style="font-size:30px; font-weight: bolder; text-align:center ">可能是Tianbot mini的第一个订单的开箱</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/17
>
> 原文作者：dabing3000
>
> 原文标题：tianbot_mini开箱以及入门配置


关注Tianbot mini有段时间了，直播的时候果断出手，可能是全网第一个订单吧
收到快递后，打开外包装的纸箱，银色的包装箱外层还有一圈缓冲气泡袋。包装整体防护能力还不错：

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555810.webp)

将箱子整体拿出，称了一下重量，在1122克左右，略微超过1公斤，携带方便是没有问题的。这个箱子也适合日常存放，比较坚固。

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555785.webp)

打开盒子以后，就看到了Tianbot Mini的真容，以及无线接收模块和配套的ROS2GO优盘。和大家遇到的问题一样，第一层海绵需要整体取出来以后，才能将小车拿出。如果能在左右两侧嵌入一根提带，会方便很多。

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555795.webp)

将车体和所有配件拿出来，拍个大合影：

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555973.webp)

Tianbot Mini的主体重量，大约在500克：

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555809.webp)

随车还付送了一套贴纸，可以贴在激光雷达顶部

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555567.webp)

初步使用下来，有几个小细节觉得还可以继续改进：
1、蜂鸣器声音比较洪亮，不知能否调节音量大小，或者设置为静音？
2、底盘的电机转速传感器、齿轮箱是暴露在外面的，特别是齿轮箱，是否可以增加一个保护壳，防止灰尘、地毯纤维等对齿轮箱的影响？

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281555629.webp)