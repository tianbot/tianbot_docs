<p style="font-size:30px; font-weight: bolder; text-align:center ">Tianbot Mini全球首发开箱，3分钟动次打次燥起来</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/23
>
> 原文作者：古月
>
> 原文标题：Tianbot Mini全球首发开箱，3分钟动次打次燥起来


原文链接：https://www.guyuehome.com/bubble/detail/id/23
原文作者：古月
原文标题：Tianbot Mini全球首发开箱，3分钟动次打次燥起来


暑假参加了古月学校的暑假培训班之后，对智能小车的兴趣越来越强烈，想拥有一辆属于自己的智能小车，正好天之博特开发出了一辆mini智能小车，当时看视频觉得性价比挺高，所以当时在首发时买了一辆。发货速度挺快，顺丰包邮，当时打开就充满了惊喜，配件齐全，并且小车颜值也挺高。它的配套视频和教程也挺多的，操作简单，并且有很强的扩展功能。我就跟着视频学习，轻松晚上slam地图构建。并且售后服务也挺好，还送了很多东西，真的是一款物美价廉的小车。性价比极高，适合自己拿来来学习。




古月君终于拿到了Tianbot Mini首发的量产版，虽然很早就玩过测试版了，不过还是很激动，开箱靓照走一波。

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654199.webp)

（包装稳稳的）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654222.webp)

（拆箱之后是一个很精致的盒子，随身系统，提上也是倍儿有面子）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654142.webp)

（打开盒子啦！！！）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654247.webp)

（原来下边还有一层）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654234.webp)

（所有零部件，排排坐，选配的古月居专属定制版ROS2GO，亮Sao~~）

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281654228.webp)

（1一分钟安装，1分钟上电联网，1分钟燥起来）
