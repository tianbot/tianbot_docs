<p style="font-size:30px; font-weight: bolder; text-align:center ">床上的开箱贴</p>

> 原文链接：https://www.guyuehome.com/bubble/detail/id/20
>
> 原文作者：不太黑
>
> 原文标题：床上的开箱贴
    

这应该是Tianbot mini的第二个开箱贴（-）
啊哈哈哈！！！（我飘了！）
这是一期在床上的开箱贴，顾名思义，就是在床上开箱。
1.生图，请收好
废话先不多讲，先看看，Tianbot mini的盛世美图！！！

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625658.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625284.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625164.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625219.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625274.webp)

![](https://tianbot-pic.oss-cn-beijing.aliyuncs.com/tianbot/202109281625718.webp)

总体感觉：

快递顺丰，没的说，头天晚上揽的货，第二天下午两点就到了。

小车整体的外形都是真真极好！材质做工方面感觉来说还是不错的，看得出来设计者的用心，是经过反复打磨的作品，属实值得点赞！！！

总结：
暑期学校的时候，看到这款小车，还是很心动！但是下单确实经过成熟的思考的。

**首先，**我认可这款小车的外观设计，不同于淘宝网上的一些ROS小车，看着完全就是底盘、亚克力板啥的拼装起来，Tianbot Mini的外形，设计上是很讨喜的，也没有多余的线材漏出，看着就很舒服。

再一个，Tianbot Mini确实满足ROS入门学习者的需求，ROS2GO解决了环境安装的大问题，这个不用多说，属实入门拦路虎。同时，小车可以作为我们验证功能、算法的平台，这对于初学者来讲，可以更加专注于ROS的学习、应用以及功能开发。最后，小车简单清晰的结构，也降低了入门学习者的理解难度。

最后的最后，这是一期简单的开箱贴，希望可以更好地帮助大家了解Tianbot Mini这款产品。

属实第一次投贴，心里贼鸡儿激动！欢迎大家一起交流学习！
