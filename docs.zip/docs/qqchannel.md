---
aside: false
---

<p>
    <p align="center">QQ 频道</p>
</p>

点击链接加入QQ频道【ROS2GO交流群】：https://pd.qq.com/s/ff87jqozl


![qqChannel](./public/QQchannel.jpg)