<p style="font-size:30px ;font-weight: bolder;  text-align:center"> 开发技巧说明 </p>

- git快速使用

- linux快速使用

- markdown快速使用

- Vi/Vim快速使用

- 如何备份你的linux系统

- VScode中的开发环境配置

- 如何优雅的提问
